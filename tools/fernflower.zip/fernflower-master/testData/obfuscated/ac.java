public interface ac {
   void a() throws Exception;
}
