public class aq extends ap {
   private volatile long d;
   private volatile long e;
   private final String f;
   private static final long g = 4611686018427387903L;
   private final Double h;

   public aq(String var1, String var2, String var3, Double var4) {
      super(var1, var2);
      this.f = var3;
      this.h = var4;
   }

   public String c() {
      return this.f;
   }

   public void a(long param1) {
      // $FF: Couldn't be decompiled
   }

   public double d() {
      // $FF: Couldn't be decompiled
   }

   public Double e() {
      return this.h;
   }
}
