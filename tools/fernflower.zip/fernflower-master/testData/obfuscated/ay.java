public interface ay {
   void a(a0 var1);
}
