import java.lang.Thread.State;

public class ao implements Comparable<ao> {
   protected String a;
   protected State b;
   protected double c;
   protected long d;
   protected long e;

   public String a() {
      return this.a;
   }

   public State b() {
      return this.b;
   }

   public double c() {
      return this.c;
   }

   public int a(ao param1) {
      // $FF: Couldn't be decompiled
   }
}
