public interface ad {
   String a();
}
