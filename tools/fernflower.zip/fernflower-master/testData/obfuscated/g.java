public interface g<V> {
   boolean a(V var1);
}
