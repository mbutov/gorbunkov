public class a9 extends RuntimeException {
   private static final long serialVersionUID = 1180433275280350911L;

   public a9(String var1, Throwable var2) {
      super(var1, var2);
   }

   public a9(Throwable var1) {
      super(var1);
   }

   public a9(String var1) {
      super(var1);
   }
}
