public interface f<K, V> {
   V a(K var1);
}
