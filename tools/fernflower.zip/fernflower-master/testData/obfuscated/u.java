public interface u {
   void a(Class<?> var1) throws Exception;

   void a() throws Exception;
}
