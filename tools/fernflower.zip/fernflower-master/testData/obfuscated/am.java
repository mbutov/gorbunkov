public interface am {
   void a(k<ak> var1);
}
