import java.util.List;
import javax.xml.xpath.XPathExpressionException;

public interface a0 {
   a0 a(String var1) throws XPathExpressionException;

   List<a0> b(String var1) throws XPathExpressionException;

   a0[] c(String var1) throws XPathExpressionException;

   String d(String var1) throws XPathExpressionException;

   o e(String var1) throws XPathExpressionException;

   boolean f(String var1) throws XPathExpressionException;

   String a();
}
