import java.util.Collection;

public interface k<T> {
   void a(T var1);

   void a(Collection<? extends T> var1);
}
