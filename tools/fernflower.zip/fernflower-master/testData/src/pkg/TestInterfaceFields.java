package pkg;

import java.math.BigDecimal;

public interface TestInterfaceFields {
  BigDecimal BIG_ZERO = BigDecimal.ZERO;
  int MAX_BYTE_VALUE = Byte.MAX_VALUE;
}