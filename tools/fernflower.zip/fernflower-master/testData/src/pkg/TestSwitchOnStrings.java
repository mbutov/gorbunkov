package pkg;

public class TestSwitchOnStrings {
  public int testSOE(String s) {
    switch (s) {
      case "xxx":
        return 2;
      case "yyy":
        return 1;
    }
    return 0;
  }
}
