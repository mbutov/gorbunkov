package pkg

val sl1: suspend () -> Unit = {
    println("SL1")
}