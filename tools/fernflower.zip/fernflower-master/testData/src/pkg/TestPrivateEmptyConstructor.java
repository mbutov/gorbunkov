package pkg;

public final class TestPrivateEmptyConstructor {
   private TestPrivateEmptyConstructor() {}

   public final void test() {
		System.out.println("test");
   }
}