package pkg;

class TestSuperInnerBase {
  protected abstract class Inner {
    protected Inner() { }
  }
}